-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 03, 2021 at 01:27 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userform`
--

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` text NOT NULL,
  `contact` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`, `contact`) VALUES
(20, 'Roman sharif', 'Roman@gmail.com', '$2y$10$urR3zSNQGPwFN38JjSnKh.8eclXVOZ.9Ro86vjMSUUqNx9eVgfW12', 0, 'verified', 1010200304),
(21, 'Sakib', 'sakib@gmail.com', '$2y$10$CDHYU4aP1zP5erTnCasKteNbPTlU.cBVN1OnUTtC.ya/7p5kcZCbO', 0, 'verified', 1893630373),
(22, 'sami', 'sami@gmail.com', '$2y$10$zkD2DdhEnOzZc2rCcsymBuY80m2szLGhxTxoHC5R3L2wFGdpHYWQe', 0, 'verified', 1893630373),
(28, 'Biozed Hossain', 'biozedhossain1@gmail.com', '$2y$10$db5AU0bshbjDGt9kffWRWOSXBoob2ZulP6Cxrb9.FSowW.cxTnuRS', 263338, 'verified', 1400300234),
(29, 'Md Akash', 'akash@gmail.com', '$2y$10$6NVybCfgQQ.J3AJs/jQgfeeZY3IwDHOUN/PfKWT3BF8mO1YUK3Vsy', 918869, 'notverified', 1234567890),
(30, 'Md Romel', 'romel@gmail.com', '$2y$10$pUwfZCw4J8WkiUZwjoJH8u1G1UPXVp4fl4l1GVoeevofWG4YVHdue', 133235, 'notverified', 1234567890);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
